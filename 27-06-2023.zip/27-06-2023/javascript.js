let x=20,y=50;
// var W=x+y;
// var Z=x-y;
// var A=x*y;
// var B=x/y;
console.log("sum of x+y is:"+(x+y));
document.write("<br>sum of x+y is:"+(x+y) );

console.log("subtraction of x-y is:"+ (x-y));
document.write("<br> subtraction of x-y is:"+  (x-y));

console.log("multiplication of x*y is:"+  (x*y));
document.write("<br>multiplication of x*y is:"+  (x*y));

console.log("division of x/y is:"+  (x/y));
document.write("<br>division of x/y is:"+  (x/y));